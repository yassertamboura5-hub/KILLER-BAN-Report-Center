package com.killerban.v2;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.Intent;
import android.net.Uri;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import android.text.*;
import java.util.*;

public class MainActivity extends Activity {
    int bg=Color.rgb(10,7,20), panel=Color.rgb(24,19,42), accent=Color.rgb(168,85,247), white=Color.rgb(248,245,255), muted=Color.rgb(190,181,208);
    LinearLayout root;
    EditText numberField, detailsField, emailField;
    String cause="Harcèlement";
    final String[] causes={"Harcèlement","Spam","Usurpation d’identité","Arnaque","Compte compromis","Contenu inapproprié","Menaces ou violence","Autre"};
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);home();}
    GradientDrawable shape(int color,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(18));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
    int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    void pad(View v,int a){v.setPadding(dp(a),dp(a),dp(a),dp(a));}
    void gap(LinearLayout l,int h){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    Button button(String label,Runnable action){Button b=new Button(this);b.setText(label);b.setTextColor(white);b.setAllCaps(false);b.setTextSize(14);b.setBackground(shape(Color.rgb(43,29,65),accent));b.setOnClickListener(v->action.run());return b;}
    void addBtn(LinearLayout l,String label,Runnable action){Button b=button(label,action);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(10);l.addView(b,p);}
    void home(){
        root=column();root.setBackgroundColor(bg);ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.addView(root);setContentView(sc);pad(root,18);
        TextView title=text("ϟ  KILLER BAN V2",25,white,true);root.addView(title);root.addView(text("SIGNALEMENT • PROTECTION • ASSISTANCE",10,muted,true));gap(root,24);
        LinearLayout hero=column();pad(hero,20);hero.setBackground(shape(panel,Color.rgb(77,45,105)));root.addView(hero);
        hero.addView(text("ESPACE D’ASSISTANCE WHATSAPP",11,Color.rgb(66,232,255),true));gap(hero,8);hero.addView(text("PROTÈGE TON ESPACE.",29,white,true));gap(hero,6);hero.addView(text("Prépare une demande, règle ton interface et retrouve chaque option dans sa propre fenêtre.",14,muted,false));gap(hero,14);
        addBtn(hero,"⚑  Créer un signalement",()->reportDialog());gap(root,18);
        addBtn(root,"⚑  Signalement  —  préparer une demande",()->reportDialog());
        addBtn(root,"◈  Apparence  —  luminosité et couleur",()->appearanceDialog());
        addBtn(root,"♫  Média & audio  —  fichier local",()->audioDialog());
        addBtn(root,"⚙  Paramètres  —  préférences",()->settingsDialog());
        addBtn(root,"▤  Mes brouillons  —  demandes enregistrées",()->draftsDialog());
        addBtn(root,"ⓘ  À propos & contact",()->aboutDialog());
        gap(root,12);TextView note=text("Les demandes ne sont pas envoyées automatiquement. KILLER BAN V2 n’est pas affilié à WhatsApp ou Meta et ne peut pas bannir de comptes.",12,muted,false);root.addView(note);
    }
    EditText edit(String hint,boolean multi){EditText e=new EditText(this);e.setTextColor(white);e.setHintTextColor(muted);e.setHint(hint);e.setTextSize(15);e.setPadding(dp(12),dp(10),dp(12),dp(10));e.setBackground(shape(Color.rgb(13,10,25),Color.rgb(67,54,89)));if(multi){e.setMinLines(4);e.setGravity(Gravity.TOP);}return e;}
    LinearLayout dialogContent(){LinearLayout c=column();c.setPadding(dp(18),dp(8),dp(18),dp(12));return c;}
    AlertDialog dialog(String title,LinearLayout content){ScrollView s=new ScrollView(this);s.addView(content);AlertDialog d=new AlertDialog.Builder(this).setTitle(title).setView(s).setNegativeButton("Fermer",null).create();d.show();d.getWindow().setBackgroundDrawableResource(android.R.color.transparent);return d;}
    void reportDialog(){
        LinearLayout c=dialogContent();c.addView(text("Choisis un motif correspondant à un problème réel.",13,muted,false));gap(c,10);
        Spinner sp=new Spinner(this);sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,causes));c.addView(sp);sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){} public void onItemSelected(android.widget.AdapterView<?> a,View v,int p,long id){cause=causes[p];}});
        gap(c,10);c.addView(text("Numéro concerné (indicatif inclus)",13,white,true));numberField=edit("+226 XX XX XX XX",false);c.addView(numberField);gap(c,10);
        c.addView(text("Description des faits",13,white,true));detailsField=edit("Décris les faits, la date et les éléments utiles…",true);c.addView(detailsField);gap(c,10);
        c.addView(text("E-mail de contact (facultatif)",13,white,true));emailField=edit("adresse@exemple.com",false);c.addView(emailField);gap(c,12);
        addBtn(c,"Enregistrer le brouillon",()->{saveDraft();Toast.makeText(this,"Brouillon enregistré sur cet appareil",Toast.LENGTH_SHORT).show();});
        addBtn(c,"Préparer le message e-mail ↗",()->{String body="Bonjour le support WhatsApp,\n\nJe souhaite signaler le problème suivant.\nMotif : "+cause+"\nNuméro concerné : "+numberField.getText().toString()+"\nDescription : "+detailsField.getText().toString()+"\nContact : "+emailField.getText().toString()+"\n\nMerci.";Intent i=new Intent(Intent.ACTION_SENDTO,Uri.parse("mailto:"));i.putExtra(Intent.EXTRA_SUBJECT,"Demande d’assistance WhatsApp — "+cause);i.putExtra(Intent.EXTRA_TEXT,body);try{startActivity(Intent.createChooser(i,"Choisir une application e-mail"));}catch(Exception e){Toast.makeText(this,"Aucune application e-mail installée",Toast.LENGTH_LONG).show();}});
        dialog("⚑ Préparer un signalement",c);
    }
    void saveDraft(){getPreferences(0).edit().putString("draft_cause",cause).putString("draft_number",numberField.getText().toString()).putString("draft_details",detailsField.getText().toString()).putString("draft_email",emailField.getText().toString()).apply();}
    void draftsDialog(){LinearLayout c=dialogContent();String n=getPreferences(0).getString("draft_number",""),de=getPreferences(0).getString("draft_details",""),ca=getPreferences(0).getString("draft_cause","");if(n.isEmpty()&&de.isEmpty()){c.addView(text("Aucun brouillon enregistré.",15,muted,false));}else{c.addView(text("Motif : "+ca,16,white,true));gap(c,8);c.addView(text("Numéro : "+n,14,muted,false));gap(c,8);c.addView(text("Description : "+de,14,muted,false));gap(c,12);addBtn(c,"Recharger dans le formulaire",()->{reportDialog();});addBtn(c,"Supprimer le brouillon",()->{getPreferences(0).edit().remove("draft_cause").remove("draft_number").remove("draft_details").remove("draft_email").apply();Toast.makeText(this,"Brouillon supprimé",Toast.LENGTH_SHORT).show();});}dialog("▤ Mes brouillons",c);}
    void appearanceDialog(){LinearLayout c=dialogContent();c.addView(text("Luminosité",14,white,true));SeekBar sb=new SeekBar(this);sb.setMax(100);sb.setProgress(80);c.addView(sb);sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean u){float f=.55f+p/220f;root.setAlpha(f+.2f);}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});gap(c,12);c.addView(text("Couleur néon",14,white,true));String[] colors={"Violet électrique","Cyan","Rose","Vert laser","Orange"};int[] vals={Color.rgb(168,85,247),Color.rgb(66,232,255),Color.rgb(255,79,163),Color.rgb(155,255,101),Color.rgb(255,155,66)};Spinner sp=new Spinner(this);sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,colors));c.addView(sp);sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){}public void onItemSelected(android.widget.AdapterView<?> a,View v,int p,long id){accent=vals[p];}});addBtn(c,"Appliquer la couleur",()->{home();Toast.makeText(this,"Apparence mise à jour",Toast.LENGTH_SHORT).show();});dialog("◈ Apparence",c);}
    void audioDialog(){LinearLayout c=dialogContent();c.addView(text("Android permet de choisir un fichier audio local avec le sélecteur système.",14,muted,false));gap(c,12);addBtn(c,"Choisir un fichier audio",()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("audio/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,44);});dialog("♫ Média & audio",c);}
    @Override protected void onActivityResult(int r,int result,Intent data){super.onActivityResult(r,result,data);if(r==44&&result==RESULT_OK&&data!=null){Uri u=data.getData();Intent play=new Intent(Intent.ACTION_VIEW);play.setDataAndType(u,"audio/*");play.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);try{startActivity(play);}catch(Exception e){Toast.makeText(this,"Impossible d’ouvrir ce fichier audio",Toast.LENGTH_SHORT).show();}}}
    void settingsDialog(){LinearLayout c=dialogContent();CheckBox fx=new CheckBox(this);fx.setText("Effets visuels néon");fx.setTextColor(white);fx.setChecked(true);c.addView(fx);CheckBox an=new CheckBox(this);an.setText("Animations de l’interface");an.setTextColor(white);an.setChecked(true);c.addView(an);CheckBox confirm=new CheckBox(this);confirm.setText("Confirmer avant d’ouvrir l’e-mail");confirm.setTextColor(white);confirm.setChecked(true);c.addView(confirm);addBtn(c,"Enregistrer les préférences",()->Toast.makeText(this,"Préférences enregistrées",Toast.LENGTH_SHORT).show());dialog("⚙ Paramètres",c);}
    void aboutDialog(){LinearLayout c=dialogContent();c.addView(text("KILLER BAN V2 est un outil indépendant pour préparer une demande d’assistance. Il ne peut pas suspendre un compte et ne transmet pas automatiquement les signalements.",15,muted,false));gap(c,14);addBtn(c,"Ouvrir le centre d’aide WhatsApp ↗",()->{Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.whatsapp.com/contact/"));startActivity(i);});dialog("ⓘ À propos & contact",c);}
}
