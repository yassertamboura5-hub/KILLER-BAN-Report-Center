# KILLER BAN V2 — Android

Projet Android natif (Java) avec fenêtres séparées pour :
- Signalement : motif, numéro, description, contact, brouillon et préparation d'un e-mail.
- Apparence : luminosité et palette néon.
- Média & audio : choix d'un fichier audio local.
- Paramètres.
- Mes brouillons enregistrés localement.
- À propos et centre d'aide WhatsApp.

## Construire l'APK
Le workflow GitHub Actions `.github/workflows/build-apk.yml` compile automatiquement l'application sur `push` ou depuis l'onglet Actions (workflow_dispatch). Télécharge ensuite l'artefact `KILLER-BAN-V2-Android-APK`; il contient `app-debug.apk`.

Pour une compilation locale avec Android SDK installé :
```bash
gradle assembleDebug
```

L'APK debug est généré dans `app/build/outputs/apk/debug/app-debug.apk`.

Note : l'application est indépendante et ne peut pas bannir des comptes WhatsApp. Elle prépare uniquement des messages que l'utilisateur vérifie et envoie lui-même.
